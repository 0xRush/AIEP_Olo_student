policy_docs — 24 short policy documents for Olo Retail, a company that does not
exist. Written for this course, CC0.

docs/POL-1xx.md   one document, '## <n>. <heading>' per section
manifest.csv      doc_id, title, category, updated, n_sections, file, n_words

Nothing in these documents is in any model's training data, which is the point:
W7D3 asks a model one of these questions with no context and it must invent an
answer. Two documents disagree with each other on how long store credit lasts
(POL-103 and POL-119) — that disagreement is W7D3's last task, not a mistake.
